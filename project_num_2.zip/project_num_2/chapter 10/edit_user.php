<?php //Script 10.3 Edit user
include (CHAPTER_PATH.'/'.$chapter.'/includes/header.php');

// connect to the db
require(CONNECT);

echo "<div id='content'>";
echo '<h1>Edit User</h1>';

// Get a valid user ID, through GET or POST or Select:
if ( (isset($_GET['id'])) && (is_numeric($_GET['id'])) ) { // From view_users.php
	$id = $_GET['id'];
} elseif ( (isset($_POST['id'])) && (is_numeric($_POST['id'])) ) { // Form submission.
	$id = $_POST['id'];
} else { // No valid ID, Select one from dropdown
	//get all customer names to populate dropdown menu
	$q = "SELECT CONCAT_WS(', ',last_name, first_name) AS customer, DATE_FORMAT(registration_date, '%M %d, %Y') AS dr, user_id AS id FROM site_users ORDER BY last_name ASC";		
	if($r = mysqli_query($link,$q) ){
		echo "<form action='' method='post' ><p><label for='c'>Select Customer to Edit</label>";
		echo "<select id='c' name='id'>";
		while($row = mysqli_fetch_assoc($r)) {
			echo "<option";
			echo (isset($_POST['customer']) && $_POST['customer'] == $row['customer'])? ' selected':'';
			echo " value='$row[id]'>$row[customer]</option>";
		}	
		echo "</select></p><input type='submit' name='select' value='Select'/></form>";
	} else {
		echo "We are experiencing technical difficulties. Try back later.";
	}
}

//if ID is set proceed with form
if(isset($id)) {

	// Check if the update form has been submitted:
	if (isset($_POST['update'])) {
		$errors = array();

		// check each field for validity, assign error message if fails
		// first_name
		if (empty($_POST['first_name'])) {
			$errors['fn'] = 'Please enter a first name.';
			$fn = null;
		} else {
			$fn = mysqli_real_escape_string($link,trim($_POST['first_name']));
		}

		// last_name
		if (empty($_POST['last_name'])) {
			$errors['ln'] = 'Please enter a last name.';
			$ln = null;
		} else {
			$ln = mysqli_real_escape_string($link,trim($_POST['last_name']));
		}

		// email 
		if (empty($_POST['email'])) {
			$errors['e'] = 'Please enter an email address.';
			$e = null;
		} elseif (!(filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL))) {
			$errors['e'] = 'Your email is not in a valid format.';
			$e = $_POST['email'];
		} else {
			$e = mysqli_real_escape_string($link,trim($_POST['email']));
			//prevent users with duplicate email addresses
			$q = "SELECT user_id FROM site_users WHERE email='$e' AND user_id != $id";
			if ($r = @mysqli_query($link, $q)) {
				if(mysqli_num_rows($r) != 0) {
					$errors['e'] = 'Sorry, that email is already taken. Please enter a different email address.';
					$e = $_POST['email'];
				}
				// free result set 
				mysqli_free_result($r);
			}	
		}

		if (empty($errors)) { // If everything's OK.
			// Make the query:
			$q = "UPDATE site_users SET first_name='$fn', last_name='$ln', email='$e' WHERE user_id=$id LIMIT 1";
			$r = mysqli_query ($link, $q);
			
			if (mysqli_affected_rows($link) == 1) { // If it ran OK.
				$message = '<p>The user has been updated.<br />';	
				$message .= mysqli_info($link).'</p>';
			} elseif(mysqli_affected_rows($link) == 0) {
				$message = '<p>Duplicate user information. User has not been updated.<br />';
				$message .= mysqli_info($link).'</p>';
			} else { // If it did not run OK.
				$message = '<p class="error">The user could not be updated due to a system error. We apologize for any inconvenience.<br />'; // Public message.
				$message .= mysqli_info($link).'</p>';
				$message .= '<p>' . mysqli_error($link) . '<br />Query: ' . $q . '</p>'; // Debugging message.
			}
			// provide feedback from submission
			echo '<div class="message">'.$message.'</div>';
			
		} else {
			$errors['flag'] = "<div class='error-message error'><h2>Error</h2><p>Please double check your information. User was not updated.</p></div>";
		}
	} else {
		$fn=null;
		$ln=null;
		$e=null;
	}

	//display the form with any error messages.
	$q = "SELECT first_name, last_name, email FROM site_users WHERE user_id=$id";		
	$r = mysqli_query ($link, $q);

	if (mysqli_num_rows($r) == 1) { // Valid user ID, show the form.
		echo (isset($errors['flag']))? $errors['flag'] : '';
		// Get the user's information:
		$row = mysqli_fetch_array ($r, MYSQLI_NUM);
		// Create the form:
		?>
		<form action="" method="post">
			<p>
				<label for="fn">First Name: </label>
				<input type="text" id="fn" name="first_name" size="15" maxlength="15" value="<?php echo stripslashes((!empty($fn))?$fn: $row[0]); ?>" />
				<?php echo (isset($errors['fn']))?'<span class="error">'.$errors['fn'].'</span>' : ''; ?>
			</p>
			<p>
				<label for="ln">Last Name: </label>
				<input type="text" id="ln" name="last_name" size="15" maxlength="30" value="<?php echo stripslashes((!empty($ln))?$ln: $row[1]); ?>" />
				<?php echo (isset($errors['ln']))?'<span class="error">'.$errors['ln'].'</span>' : ''; ?>
			</p>
			<p>
				<label for="e">Email Address: </label>
				<input type="text" id="e" name="email" size="20" maxlength="60" value="<?php echo (!empty($e))?$e: $row[2]; ?>" />
				<?php echo (isset($errors['e']))?'<span class="error">'.$errors['e'].'</span>' : ''; ?>
			</p>
			<p>
				<input type="submit" name="update" value="Apply Changes" />
				<input type="hidden" name="id" value="<?php echo $id; ?>" />
			</p>
		</form>

		<?php
	} else { // Not a valid user ID.
		echo '<p class="error">This page has been accessed in error.</p>';
	}
}

// disconnect from the db
require(DISCONNECT);

echo "</div>";
include (CHAPTER_PATH.'/'.$chapter.'/includes/footer.php');
?>

<?php # Script  10.5 view users with pagination and column sortability!
// This script retrieves all the records from the users table.
 
include (CHAPTER_PATH.'/'.$chapter.'/includes/header.php');

echo "<div id='content'>";
echo '<h1>Registered Users</h1>';

// connect to the db
require(CONNECT);

// START PAGINATION CONFIG
//allow user to set results per page - post(from form submission) overrides get(in pagination links)
if(isset($_POST['d']) && is_numeric($_POST['d']) && $_POST['d'] > 0 ) {
	$display = $_POST['d'];
} elseif(isset($_GET['d']) && is_numeric($_GET['d']) && $_GET['d'] > 0 ) {
	$display = $_GET['d'];
}else {
	$display = 10;
}

//determine which page we are on using url parameters
if (isset($_GET['p']) && is_numeric($_GET['p'])) { 
	$page = $_GET['p'];
} else {
	$page = 1;
}
// Determine how many total pages in result set
$q = "SELECT COUNT(user_id) FROM site_users";
$r = @mysqli_query ($link, $q);
$row = @mysqli_fetch_array ($r, MYSQLI_NUM);
$totalResults = $row[0];
// Calculate the number of pages...
if ($totalResults > $display) { // More than 1 page.
	$pages = ceil ($totalResults/$display);
} else {
	$pages = 1;
}
//reset $page if user is naughty and overwrites $_GET variable
if($page>$pages) $page=$pages;
if($page<1) $page=1;

// set the starting point in the database to return results...
$start = (($page * $display) - $display);
// END PAGINATION Config

// START SORTING functionality
// Default is by last name ASC.
$sort = (isset($_GET['sort'])) ? $_GET['sort'] : 'ln';

// Determine the sorting order:
switch ($sort) {
	case 'ln':
		$order_by = 'last_name';
		$col = 'Last Name';
		break;
	case 'fn':
		$order_by = 'first_name';
		$col = 'First Name';
		break;
	case 'e':
		$order_by = 'email';
		$col = 'Email';
		break;
	case 'rd':
		$order_by = 'registration_date';
		$col = 'Registration Date';
		break;
	default:
		$order_by = 'last_name';
		$sort = 'ln';
		break;
}
$dir = (isset($_GET['dir'])) ? $_GET['dir'] : 'ASC';
switch ($dir) { // allow only two values
	case 'DESC':
		$dir='DESC';
		break;
	default:
		$dir = 'ASC';
		break;
}
//format string for display
$column = ucwords(str_replace('_', ' ', $order_by));
$column .= ($dir=='ASC')?' Ascending':' Descending';
//format string for sql orderby clause
$order_by .= ' '.$dir;
// END SORTING 

// build the query:
$q = "SELECT last_name, first_name, email, DATE_FORMAT(registration_date, '%M %d, %Y') AS dr, user_id FROM site_users ORDER BY $order_by LIMIT $start, $display";		

// run query
if($r = @mysqli_query ($link, $q)) { 
	// Count the number of returned rows:
	$num = mysqli_num_rows($r);

	if($num > 0) {
		// Print how many users there are:
		echo "<div class='message'>Viewing ";
		echo $start+1;
		echo "-";
		echo ($page!=$pages)? $start+$display : $totalResults;
		echo "  of <b>$totalResults</b> users. Sorted by $column.</div>\n";
		?>
		<form method="post" action="">
			<p>
				<label for="d">Users per page:</label>
				<input type="text" name="d" id="d" value="<?php echo $display; ?>"/>
				<input type="submit" name="submit" value="Apply" />
			</p>
		</form>

		<?php // Table header:?>
		<table>
			<thead>
				<tr>
					<th>Edit</th>
					<th>Delete</th>
					<th><a href="index.php?chapter=10&amp;script=10.5&amp;d=<?php echo $display; ?>&amp;p=<?php echo $page; ?>&amp;sort=ln&amp;dir=<?php echo ($sort=='ln' && $dir=='ASC')?'DESC':'ASC'; ?>">Last Name</a></th>
					<th><a href="index.php?chapter=10&amp;script=10.5&amp;d=<?php echo $display; ?>&amp;p=<?php echo $page; ?>&amp;sort=fn&amp;dir=<?php echo ($sort=='fn' && $dir=='ASC')?'DESC':'ASC'; ?>">First Name</a></th>
					<th><a href="index.php?chapter=10&amp;script=10.5&amp;d=<?php echo $display; ?>&amp;p=<?php echo $page; ?>&amp;sort=e&amp;dir=<?php echo ($sort=='e' && $dir=='ASC')?'DESC':'ASC'; ?>">Email</a></th>
					<th><a href="index.php?chapter=10&amp;script=10.5&amp;d=<?php echo $display; ?>&amp;p=<?php echo $page; ?>&amp;sort=rd&amp;dir=<?php echo ($sort=='rd' && $dir=='ASC')?'DESC':'ASC'; ?>">Date Registered</a></th>
				</tr>
			</thead>
			<tbody>	
			<?php // Fetch and print all the records:
			while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
				echo '<tr>
					<td><a href="index.php?chapter=10&amp;script=10.3&amp;id=' . $row['user_id'] . '">Edit</a></td>
					<td><a href="index.php?chapter=10&amp;script=10.2&amp;id=' . $row['user_id'] . '">Delete</a></td>
					<td>' . $row['last_name'] . '</td>
					<td>' . $row['first_name'] . '</td>
					<td>' . $row['email'] . '</td>
					<td>' . $row['dr'] . '</td>
				</tr>';
			}
		echo '</tbody></table>';
		mysqli_free_result ($r);
	} else {
		// no results
		echo '<p class="error-message error">There are currently no registered users.</p>';
	}
	// Build navigation through paginated results
	if ($pages > 1) {
		
		echo '<p class="pagination">';
		
		// If it's not the first page, make a Previous button:
		if ($page != 1) {
			echo '<a href="index.php?chapter=10&amp;script=10.5&amp;d='.$display.'&amp;p='.($page-1).'&amp;sort='.$sort.'&amp;dir='.$dir.'">Previous</a> ';
		}
		
		// Make all the numbered pages:
		for ($i = 1; $i <= $pages; $i++) {
			if ($i != $page) {
				echo '<a href="index.php?chapter=10&amp;script=10.5&amp;d='.$display.'&amp;p='.$i.'&amp;sort='.$sort.'&amp;dir='.$dir.'">' . $i . '</a> ';
			} else {
				echo '<b>'.$i.'</b> ';
			}
		} // End of FOR loop.
		
		// If it's not the last page, make a Next button:
		if ($page != $pages) {
			echo '<a href="index.php?chapter=10&amp;script=10.5&amp;d='.$display.'&amp;p='.($page+1).'&amp;sort='.$sort.'&amp;dir='.$dir.'">Next</a>';
		}
		echo '</p>';
		
	} // End of navigation

} else {
	//query unsuccessful
	echo '<h2>Error</h2><p class="error-message error">There was an error accessing the database. Please try again later.</p>';
}
// close db connection 
require(DISCONNECT);

echo "</div>";
include (CHAPTER_PATH.'/'.$chapter.'/includes/footer.php');
?>

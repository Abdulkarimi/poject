<?php # Script 9.6 - view users.php #2 (with Count)
// This script retrieves all the records from the users table.
 
include (CHAPTER_PATH.'/'.$chapter.'/includes/9.1.php');

echo "<div id='content'>";
echo '<h1>Registered Users</h1>';

// connect to the db
require(CONNECT);

// build query 
$q = "SELECT CONCAT(last_name, ', ', first_name) AS 'User Name', DATE_FORMAT(registration_date, '%M %d, %Y') AS 'Date Registered' FROM site_users ORDER BY registration_date ASC";		
// $q = "ERROR";

// run query
if($r = @mysqli_query ($link, $q)) { 
	// Count the number of returned rows:
	$num = mysqli_num_rows($r);

	if($num > 0) {
		// Print how many users there are:
		echo "<div class='message'>There are currently $num registered users.</div>\n";
		//format results in table
		results_to_table($r,'');
	} else {
		// no results
		echo '<p class="error-message error">There are currently no registered users.</p>';
	}

	// free result set 
	mysqli_free_result($r);

} else {
	//query unsuccessful
	echo '<h2>Error</h2><p class="error-message error">There was an error accessing the database. Please try again later.</p>';
}
// close db connection 
require(DISCONNECT);

echo "</div>";
include (CHAPTER_PATH.'/'.$chapter.'/includes/9.2.php');
?>

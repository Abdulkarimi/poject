<?php # Script 9.8 - index.php

$title = 'Welcome to this Site!';
include (CHAPTER_PATH.'/'.$chapter.'/includes/9.1.php');
echo "<div id='content'>";
?>

<h1>Content Header</h1>

	<p>This is where the page-specific content goes. This section, and the corresponding header, will change from one page to the next.</p>
	
	<p>Volutpat at varius sed sollicitudin et, arcu. Vivamus viverra. Nullam turpis. Vestibulum sed etiam. Lorem ipsum sit amet dolore. Nulla facilisi. Sed tortor. Aenean felis. Quisque eros. Cras lobortis commodo metus. Vestibulum vel purus. In eget odio in sapien adipiscing blandit. Quisque augue tortor, facilisis sit amet, aliquam, suscipit vitae, cursus sed, arcu lorem ipsum dolor sit amet.</p>

<?php
echo "</div>";
include (CHAPTER_PATH.'/'.$chapter.'/includes/9.2.php');
?>